﻿using System;     
                   
namespace Test_Visual_Studio {
    class Program {
                   
        static void Main(string[] args) {
                                    
            Console.WriteLine("Hello World!");
        }         
    };             
}                  